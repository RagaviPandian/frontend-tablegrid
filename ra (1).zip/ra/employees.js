function getJSON(url, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.responseType = 'json';
  xhr.onload = function() {
    var status = xhr.status;
    if (status === 200) {
      callback(null, xhr.response);
    } else {
      callback(status, xhr.response);
    }
  };
    xhr.send();
};

function loadEmployess(data_file) {
  getJSON("data.json", function(err, data){
  if (err !== null) {
    alert('Something went wrong while loading json file: ' + err);
  } else {
    var employee_data='';
	data.forEach(function(value,index){
	  employee_data += '<tr>';
	  employee_data += '<td>' +value.id+'</td>';
	  employee_data += '<td>' +value.first_name+ ' ' + value.last_name + '</td>';
	  employee_data += '<td>' +value.email+'</td>';
	  employee_data += '<td>' +value.gender+'</td>';
	  employee_data += '<td>' +value.City+'</td>';
	  employee_data += '<td>' +value.phone+'</td>';
	  employee_data += '<td>' +value["Job Title"]+'</td>';
	  employee_data += '<td>' +value.Salary+'</td>';
	  employee_data += '</tr>';
    });
      document.getElementById('employee-list').innerHTML = employee_data;
	}
  });
}
  
(function() {
  loadEmployess();
})();